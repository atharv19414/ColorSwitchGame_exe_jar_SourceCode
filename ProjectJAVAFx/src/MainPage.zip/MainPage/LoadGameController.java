package MainPage;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;

import java.net.URL;
import java.util.ResourceBundle;

public class LoadGameController implements Initializable {

    @FXML
    private ImageView backButton;
    @FXML
    private AnchorPane loadGamePane;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

    }

    @FXML
    public void goBack(MouseEvent actionEvent) throws Exception {
        Pane pane= FXMLLoader.load(getClass().getResource("MainPage.fxml"));
        loadGamePane.getChildren().setAll(pane);
    }
}
