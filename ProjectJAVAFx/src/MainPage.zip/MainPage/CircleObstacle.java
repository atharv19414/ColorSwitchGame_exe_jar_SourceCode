package MainPage;

import java.io.Serializable;

public class CircleObstacle extends Obstacles implements Serializable {

    public CircleObstacle(double posX, double posY, double angle) {
        super(posX, posY, angle);
    }
}
