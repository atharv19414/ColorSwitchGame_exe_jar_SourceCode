package MainPage;

import java.io.Serializable;
import java.util.ArrayList;

public class Database implements Serializable {
    private static Database d;

    private ArrayList<DataStore> dataBaseList;

    public Database(){
        dataBaseList = new ArrayList<DataStore>();
    }

    public void addData(DataStore d) {
        dataBaseList.add(d);
    }

    public void removeData(DataStore d){
        if(dataBaseList.contains(d)){
            dataBaseList.remove(d);
        }
    }

    public ArrayList<DataStore> getDataBaseList() {
        return dataBaseList;
    }
}
