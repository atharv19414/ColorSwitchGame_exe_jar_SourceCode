package MainPage;

import java.io.Serializable;
import java.util.ArrayList;

public class DataStore implements Serializable {

    private ArrayList<ArrayList<Double>> obstaclesList;
    private ArrayList<ArrayList<Double>> colorSwitchList;
    private ArrayList<ArrayList<Double>> starsList;
    private double posballX,posballY;

    public DataStore(ArrayList<ArrayList<Double>> obstaclesList,ArrayList<ArrayList<Double>> colorSwitchList,ArrayList<ArrayList<Double>> starsList,double posballX,double posballY) {
        this.obstaclesList = obstaclesList;
        this.colorSwitchList = colorSwitchList;
        this.starsList = starsList;
        this.posballX = posballX;
        this.posballY = posballY;
    }

    public ArrayList<ArrayList<Double>> getObstaclesList() {
        return obstaclesList;
    }

    public ArrayList<ArrayList<Double>> getColorSwitchList() {
        return colorSwitchList;
    }

    public ArrayList<ArrayList<Double>> getStarsList() {
        return starsList;
    }

    public double getPosballX() {
        return posballX;
    }

    public double getPosballY() {
        return posballY;
    }

    public void saveGame(){
//        Main.getCurrentDatabase().getDataBaseList().add();

    }

}
