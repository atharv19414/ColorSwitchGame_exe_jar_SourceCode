package MainPage;

import java.io.Serializable;

public class SquareObstacle extends Obstacles implements Serializable {
    public SquareObstacle(double posX, double posY, double angle) {
        super(posX, posY, angle);
    }
}
