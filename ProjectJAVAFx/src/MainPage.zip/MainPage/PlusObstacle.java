package MainPage;

import java.io.Serializable;

public class PlusObstacle extends Obstacles implements Serializable {
    public PlusObstacle(double posX, double posY, double angle) {
        super(posX, posY, angle);
    }
}
