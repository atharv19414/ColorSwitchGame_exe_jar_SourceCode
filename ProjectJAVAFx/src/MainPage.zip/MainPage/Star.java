package MainPage;

public class Star extends GameObjects {
    private int posX;
    private int posY;

    public Star(int posX, int posY) {
        super(posX, posY);
    }

    public void disappear(){


    }
}
